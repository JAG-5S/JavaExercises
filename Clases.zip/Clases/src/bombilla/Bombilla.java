package bombilla;

public class Bombilla {

    public static final boolean DEFAULT_ESTADO_INICIAL = false;

    private static int bombillasPrendidas = 0;
    private static int numBombillasCreadas = 0;

    private boolean estado;
    private int numVecesPrendida;

    public Bombilla() {
        this(DEFAULT_ESTADO_INICIAL);
    }

    public Bombilla(boolean estadoInicial) {
        this.estado = estadoInicial;

        if (estadoInicial) {
            numVecesPrendida++;
            bombillasPrendidas++;
        }

        numBombillasCreadas++;
    }

    public boolean getEstado() {
        return this.estado;
    }

    public void encender() {
        if (!this.estado) {
            this.estado = true;
            this.numVecesPrendida++;
            bombillasPrendidas++;
        }
    }

    public void apagar() {
        if (this.estado) {
            this.estado = false;
            bombillasPrendidas--;
        }
    }

    public void mostrarEstado() {
        System.out.println("Estado: " + (estado ? "Encendido" : "Apagado") +
                           ". Se ha encendido " + numVecesPrendida + " veces.");
    }

    public static int getBombillasPrendidas() {
        return bombillasPrendidas;
    }

    public static int getNumBombillasCreadas() {
        return numBombillasCreadas;
    }
}
