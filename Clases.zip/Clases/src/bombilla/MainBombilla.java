package bombilla;

public class MainBombilla {

	public static void main(String[] args) {
		
		Bombilla foco1 = new Bombilla(false);
		
		foco1.mostrarEstado();
		foco1.encender();
		foco1.mostrarEstado();
		foco1.apagar();
		foco1.encender();
		foco1.apagar();
		foco1.encender();
		foco1.apagar();
		foco1.encender();
		foco1.mostrarEstado();
	}

}
